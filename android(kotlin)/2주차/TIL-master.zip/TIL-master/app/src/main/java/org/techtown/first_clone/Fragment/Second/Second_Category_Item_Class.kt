package org.techtown.first_clone.Fragment.Second

import android.graphics.drawable.Drawable

class Second_Category_Item_Class(val image: Int?=null,val name:String?=null) {
}