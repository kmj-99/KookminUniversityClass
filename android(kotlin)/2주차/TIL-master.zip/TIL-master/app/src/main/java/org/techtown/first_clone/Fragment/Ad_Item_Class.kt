package org.techtown.first_clone.Fragment

import android.graphics.drawable.Drawable

class Ad_Item_Class(val image: Int?=null) {
}