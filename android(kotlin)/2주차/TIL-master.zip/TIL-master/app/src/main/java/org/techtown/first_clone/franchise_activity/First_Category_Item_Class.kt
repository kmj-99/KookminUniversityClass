package org.techtown.first_clone.franchise_activity

class First_Category_Item_Class(var name:String?=null) {
}