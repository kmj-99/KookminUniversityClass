package org.techtown.first_clone.franchise_activity

import android.graphics.drawable.Drawable

class First_Category_Content_Item_Class(var title:String?=null, var image: Int?=null, var text1:String?=null, var text2:String?=null, var set:String?=null, var price:String?=null,
                                        var content:String?=null)
{

}