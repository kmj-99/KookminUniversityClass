package org.techtown.first_clone.Fragment

class Category_Item_Class(var Nmae:String?=null,var Image:Int?=null,var Sub_Image:Int?=null) {
}